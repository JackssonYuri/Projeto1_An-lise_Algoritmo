def imprime_lista(lista):
    print("\nLista Inicial (Sem Ordenação):")
    print(lista)

def imprime_lista_ordenada(lista):
    print("\nLista Final (Com Ordenação):")

    print(lista)

    print("\n****** FIM DO QUICKSORT ******\n")